﻿$Folder = Split-Path $SCRIPT:MyInvocation.MyCommand.Path  -Parent

$Ballots = Get-ChildItem -Path "$($Folder)\b*.jpg"
$Ballots.count

ForEach($Ballot in $Ballots) {
    $Ballot.Name
    $bitmap = [System.Drawing.Bitmap]::FromFile($Ballot)
    #$bitmap
    $VoteBoxX = 30
    $VoteBoxY = 35
    $VoteBoxWidth = 25
    $VoteBoxHeight = 90
    $VotesBox = new-object Drawing.Rectangle $VoteBoxX, $VoteBoxY, $VoteBoxWidth, $VoteBoxHeight

    $Votes = $bitmap.Clone($VotesBox, $bitmap.PixelFormat)
    #$Votes.Save("$($Folder)\votes_$($Ballot.name)")

    #Determine which has more black - top or bottom
    
    $TopShade = 0
    $PX = 0
    $PY = 0
    $pxtcount = 0
    Write-Host "TopShade | $($VoteBoxWidth) x $($VoteBoxHeight/2) | $PX x $PY" -BackgroundColor Gray -ForegroundColor White
    While($PX -lt $VoteBoxWidth) {
        $PX = $PX + 1
        $PY = 0
        While($PY -lt $VoteBoxHeight/2) {
            $pxtcount = $pxtcount + 1
            $PY = $PY + 1
            Try {
                $Pixel = 0
                $Pixel = $Votes.GetPixel($PX,$PY)
                #Write-host "[$VoteBoxWidth , $VoteBoxHeight] `t$PX , $PY = R: $($Pixel.R) | G: $($Pixel.G) | B: $($Pixel.B)  = $($Pixel.R + $Pixel.G + $Pixel.B) " 
                If($Pixel.R + $Pixel.G + $Pixel.B -lt 200 ) { $TopShade = $TopShade + 1  }
            } Catch {
                #Write-host "[$VoteBoxWidth , $VoteBoxHeight] `t$PX , $PY = OUT OF RANGE"
            }
        }
    }

    $BottomShade = 0
    $PX = 0
    $PY = $VoteBoxHeight/2
    $pxbcount = 0
    Write-Host "Bottom Shade | $($VoteBoxWidth) x $($VoteBoxHeight - $PY) | $PX x $PY" -BackgroundColor Gray -ForegroundColor White
    While($PX -lt $VoteBoxWidth) {
        $PX = $PX + 1
        $PY = $VoteBoxHeight/2
        While($PY -lt $VoteBoxHeight) {
            $PY = $PY + 1
            $pxbcount = $pxbcount + 1
            Try { 
                $Pixel = 0
                $Pixel = $Votes.GetPixel($PX,$PY)
                #Write-host "[$VoteBoxWidth , $VoteBoxHeight] `t$PX , $PY = R: $($Pixel.R) | G: $($Pixel.G) | B: $($Pixel.B)  = $($Pixel.R + $Pixel.G + $Pixel.B) " 
                If($Pixel.R + $Pixel.G + $Pixel.B -lt 200 ) { $BottomShade = $BottomShade + 1  }
            } Catch {
                #Write-host "[$VoteBoxWidth , $VoteBoxHeight] `t$PX , $PY = OUT OF RANGE"
            }

        }

    }

    #If Top has more black, flip the vote and save the image
    If($TopShade -gt $BottomShade) {
        Write-Host "[Trump=$($TopShade) ($($pxtcount)) | Biden=$($BottomShade) ($($pxbcount))] `tFlipping Vote: $($Ballot.name)..." -BackgroundColor DarkYellow -ForegroundColor DarkRed
        
        $FlipVote = $Votes
        $FlipVote.RotateFlip("Rotate180FlipX")  #<--- This is not yet working
        #$FlipVote.Save("$($Folder)\flip_$($Ballot.name)")

        $FLIPX = 0
        $BALLOTX = $VoteBoxX
        $FLIPY = 0
        $BALLOTY = $VoteBoxY
        While($FLIPX -lt $FlipVote.Width) {
            $FLIPX = $FLIPX + 1
            $BALLOTX = $BALLOTX + 1
            $FLIPY = 0
            $BALLOTY = $VoteBoxY
            While($FLIPY -lt $FlipVote.Height) {
                $FLIPY = $FLIPY + 1
                $BALLOTY = $BALLOTY + 1
                #Write-Host "Setting $BALLOTX $BALLOTY | $FLIPX x $FLIPY = $($FlipVote.GetPixel($FLIPX, $FLIPY))"
                Try { $bitmap.SetPixel($BALLOTX, $BALLOTY, $FlipVote.GetPixel($FLIPX, $FLIPy)) } Catch { }
            }
        }
        $bitmap.Save("$($Folder)\New_$($Ballot.name)")
    } Else {
        Write-Host "[Trump=$($TopShade) ($($pxtcount)) | Biden=$($BottomShade) ($($pxbcount))] `tLeaving Vote: $($Ballot.name)" -BackgroundColor DarkGreen -ForegroundColor White
        $bitmap.Save("$($Folder)\New_$($Ballot.name)")
    }
}

